/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chess_game.Pieces;

/**
 *
 * @author Enes Kızılcın <nazifenes.kizilcin@stu.fsm.edu.tr>
 */

//This enum is using for surely define the type of pieces.
public enum PieceTypes
{
    QUEEN,
    KING,
    ROOK,
    BISHOP,
    KNIGHT,
    PAWN,
    EMPTY
}