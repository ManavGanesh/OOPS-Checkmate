package ClientSide;

import Messages.ChatMessage;
import Messages.Message;
import Messages.PlayerInfo;
import Messages.PlayRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import ClientSide.*;
import Messages.MovementMessage;
import chess_game.Boards.Board;
import chess_game.Move.Move;
import chess_game.Pieces.PieceTypes;
import chess_game.Pieces.Team;
import chess_game.Player.Player;
import java.awt.Color;
import javax.swing.JOptionPane;
import Messages.GameState;

public class ClientListenThread extends Thread {

    Client client;

    public ClientListenThread(Client client) {
        this.client = client;
    }

    @Override
    public void run() {
        while (!this.client.socket.isClosed()) {
            try {
                Message msg = (Message) (this.client.sInput.readObject());
                switch (msg.type) {
                    case START:
                        Team serverChosenTeam = (Team) msg.content;
                        this.client.setTeam(serverChosenTeam);
                        break;
                        
                    case PAIRING:
                        if (msg.content instanceof String) {
                            String opponentName = (String) msg.content;
                            this.client.game.setOpponentName(opponentName);
                        }
                        this.client.isPaired = true;
                        this.client.game.getMainMenu().getPlayBTN().setEnabled(true);
                        this.client.game.getMainMenu().getPlayBTN().setText("Start Game");
                        this.client.game.getMainMenu().getInfoLBL().setText("Matched. Click To Start Game");
                        break;
                        
                    case MATCHED:
                        this.client.isPaired = true;
                        this.client.game.getMainMenu().getPlayBTN().setEnabled(true);
                        this.client.game.getMainMenu().getPlayBTN().setText("Start Game");
                        this.client.game.getMainMenu().getInfoLBL().setText("Matched. Click To Start Game");
                        break;
                        
                    case PLAYER_LIST:
                        ArrayList<PlayerInfo> players = (ArrayList<PlayerInfo>) msg.content;
                        this.client.game.updatePlayersList(players);
                        break;
                        
                    case PLAY_REQUEST:
                        PlayRequest request = (PlayRequest) msg.content;
                        this.client.game.showPlayRequest(request);
                        break;
                        
                    case PLAY_RESPONSE:
                        PlayRequest response = (PlayRequest) msg.content;
                        if (response.isAccepted) {
                            this.client.isPaired = true;
                            this.client.game.setOpponentName(response.fromPlayerName);
                            JOptionPane.showMessageDialog(null, response.fromPlayerName + " accepted your request! Starting game...");
                            this.client.game.createGamePanel();
                        } else {
                            JOptionPane.showMessageDialog(null, response.fromPlayerName + " declined your request.");
                            this.client.game.getPlayerSelectionPanel().getSendRequestBTN().setEnabled(true);
                            this.client.game.getPlayerSelectionPanel().getStatusLBL().setText("Request declined. Try another player.");
                        }
                        break;
                        
                    case REQUEST_DENIED:
                        String requestMessage = (String) msg.content;  // Changed variable name
                        JOptionPane.showMessageDialog(null, requestMessage);
                        this.client.game.getPlayerSelectionPanel().getSendRequestBTN().setEnabled(true);
                        break;
                        
                    case CHAT:
                        ChatMessage chatMessage = (ChatMessage) msg.content;
                        String displayMessage = chatMessage.playerName + ": " + chatMessage.message;
                        if (this.client.game.getBottomGameMenu() != null) {
                            this.client.game.getBottomGameMenu().addChatMessage(displayMessage);
                        }
                        break;
                        
                    case MOVE:
                        MovementMessage movement = (MovementMessage) msg.content;
                        Board board = this.client.game.getChessBoard();
                        Player player = board.getCurrentPlayer();
                        Move move;
                        if (movement.isCastling) {
                            move = new Move(
                                board,
                                board.getTile(movement.currentCoordinate),
                                board.getTile(movement.destinationCoordinate),
                                board.getTile(movement.rookStartCoordinate),
                                board.getTile(movement.rookEndCoordinate)
                            );
                        } else if (movement.isEnPassant) {
                            move = new Move(
                                board,
                                board.getTile(movement.currentCoordinate),
                                board.getTile(movement.destinationCoordinate),
                                board.getTile(movement.enPassantCapturedPawnCoordinate)
                            );
                        } else if (movement.isPromotion) {
                            move = new Move(
                                board,
                                board.getTile(movement.currentCoordinate),
                                board.getTile(movement.destinationCoordinate)
                            );
                            move.setPromotionMove(true);
                            move.setPromotionPieceType(PieceTypes.valueOf(movement.promotionPieceType));
                        } else {
                            move = new Move(board, board.getTile(movement.currentCoordinate), board.getTile(movement.destinationCoordinate));
                        }
                        player.makeMove(board, move);
                        this.client.game.getBoardPanel().updateBoardGUI(this.client.game.getChessBoard());
                        if (move.isEnPassantMove()) {
                            if (this.client.game.getBottomGameMenu() != null && move.getKilledPiece() != null) {
                                this.client.game.getBottomGameMenu().killedPiecesListModel.addElement(move.getKilledPiece().toString());
                            }
                        } else if (move.hasKilledPiece()) {
                            if (this.client.game.getBottomGameMenu() != null) {
                                this.client.game.getBottomGameMenu().killedPiecesListModel.addElement(move.getKilledPiece().toString());
                            }
                            if (move.getKilledPiece().getType() == PieceTypes.KING) {
                                Team winnerTeam;
                                winnerTeam = (move.getKilledPiece().getTeam() == Team.BLACK) ? Team.WHITE : Team.BLACK;
                                JOptionPane.showMessageDialog(null, "Winner: " + winnerTeam.toString());
                                Message endMessage = new Message(Message.MessageTypes.END);  // Changed variable name
                                endMessage.content = null;
                                client.Send(endMessage);
                                break;
                            }
                        }
                        board.changeCurrentPlayer();
                        if (this.client.game.getBottomGameMenu() != null) {
                            this.client.game.getBottomGameMenu().getTurnLBL().setText("Your Turn");
                            this.client.game.getBottomGameMenu().getTurnLBL().setForeground(Color.GREEN);
                        }
                        break;
                        
                    case CHECK:
                        Team checkStateTeam = (Team) msg.content;
                        // Removed popup - check state is handled silently
                        break;
                        
                    case CHECKMATE:
                        Team checkmateTeam = (Team) msg.content;
                        JOptionPane.showMessageDialog(null, "Checkmate! " + checkmateTeam.toString() + " wins!");
                        this.client.isPaired = false;
                        this.client.game.createMainMenu();
                        break;
                        
                    case STALEMATE:
                        JOptionPane.showMessageDialog(null, "Stalemate! The game is a draw.");
                        this.client.isPaired = false;
                        this.client.game.createMainMenu();
                        break;
                        
                    case SAVE_GAME:
                        // Handle save game confirmation from server
                        if (msg.content instanceof GameState) {
                            GameState savedGame = (GameState) msg.content;
                            System.out.println("Game saved successfully: " + savedGame.getSaveName());
                        }
                        break;
                        
                    case LOAD_GAME:
                        // Handle load game request
                        if (msg.content instanceof GameState) {
                            GameState loadedGame = (GameState) msg.content;
                            // Load the game state
                            loadGameState(loadedGame);
                        }
                        break;

                    case LEAVE:
                        JOptionPane.showMessageDialog(null, "Enemy left. Returning to the Menu.");
                        this.client.isPaired = false;
                        this.client.game.createMainMenu();
                        break;
                        
                    case END:
                        JOptionPane.showMessageDialog(null, "Game ended. Returning to menu.");
                        this.client.isPaired = false;
                        this.client.game.createMainMenu();
                        break;
                        
                    default:
                        System.out.println("Unknown message type received: " + msg.type);
                        break;
                }

            } catch (IOException ex) {
                Logger.getLogger(ClientListenThread.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Connection lost to server");
                break;
            } catch (ClassNotFoundException ex) {
                System.out.println("Girilen class bulunamadı: " + ex.getMessage());
                break;
            } catch (Exception ex) {
                System.out.println("Unexpected error in ClientListenThread: " + ex.getMessage());
                ex.printStackTrace();
                break;
            }
        }
        
        try {
            if (this.client.socket != null && !this.client.socket.isClosed()) {
                this.client.socket.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(ClientListenThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void loadGameState(GameState gameState) {
        try {
            // Update the game board with the loaded state
            this.client.game.setChessBoard(gameState.getBoard());
            
            // Update player names
            this.client.game.setPlayerName(gameState.getPlayer1Name());
            this.client.game.setOpponentName(gameState.getPlayer2Name());
            
            // Update the board panel
            this.client.game.getBoardPanel().updateBoardGUI(gameState.getBoard());
            
            // Update the bottom menu
            if (this.client.game.getBottomGameMenu() != null) {
                this.client.game.getBottomGameMenu().setPlayerName(gameState.getPlayer1Name());
                this.client.game.getBottomGameMenu().setOpponentName(gameState.getPlayer2Name());
                
                // Update turn indicator
                if (gameState.getCurrentPlayerTeam() == this.client.getTeam()) {
                    this.client.game.getBottomGameMenu().getTurnLBL().setText("Your Turn");
                    this.client.game.getBottomGameMenu().getTurnLBL().setForeground(Color.GREEN);
                } else {
                    this.client.game.getBottomGameMenu().getTurnLBL().setText("Enemy Turn");
                    this.client.game.getBottomGameMenu().getTurnLBL().setForeground(Color.RED);
                }
            }
            
            JOptionPane.showMessageDialog(null, 
                "Game loaded successfully: " + gameState.getSaveName(),
                "Load Game", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (Exception ex) {
            System.out.println("Error loading game state: " + ex.getMessage());
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Error loading game: " + ex.getMessage(),
                "Load Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
